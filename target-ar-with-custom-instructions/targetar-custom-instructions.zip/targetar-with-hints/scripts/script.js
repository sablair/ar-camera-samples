// Here's one way to make users know that they are to look for a texture
// in order to get the effectn working.
var Reactive = require("Reactive");
var Scene = require("Scene");
var CameraInfo = require("CameraInfo");
var Diagnostics = require("Diagnostics");

var FRONT_CAMERA_INSTRUCTION = "Flip to back camera";
var BACK_CAMERA_INSTRUCTION = "Look for the logo to launch effect";
var ACTUAL_TARGET_IMAGE_HEIGHT = 752;
var ACTUAL_TARGET_IMAGE_WIDTH = 2000;
var MAX_TARGET_WIDTH = 150;

var canInstructions = Scene.root.find("canInstructions");
var txtInstruction = Scene.root.find("txtInstruction");
var plTargetImage = Scene.root.find("plTargetImage");
var ptMain = Scene.root.find("ptMain");
var txtBeenFound = Scene.root.find("txtBeenFound");

plTargetImage.width = MAX_TARGET_WIDTH;
plTargetImage.height = MAX_TARGET_WIDTH * ACTUAL_TARGET_IMAGE_HEIGHT / ACTUAL_TARGET_IMAGE_WIDTH;

// We want to possibly monitor whether this is the front facing or back facing camera
// https://developers.facebook.com/docs/camera-effects/reference/camerainfo_module
CameraInfo.captureDevicePosition.monitor({fireOnInitialValue: true}).subscribe(function (result) {
    if (result.newValue === "FRONT") {
        txtInstruction.text = FRONT_CAMERA_INSTRUCTION;
    } else if (result.newValue === "BACK") {
        txtInstruction.text = BACK_CAMERA_INSTRUCTION;
    } else {
        // This case should not happen...
    }
});

var confidenceSub = ptMain.confidence.monitor().subscribe(function (result) {
    if (result.newValue === "HIGH") {
        confidenceSub.unsubscribe();
        canInstructions.hidden = true;
        txtBeenFound.hidden = false;
    }
});